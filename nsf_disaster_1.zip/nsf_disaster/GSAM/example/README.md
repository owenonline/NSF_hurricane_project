# Cifar10 with WRN 🌁

This folder contains a simple Wide-ResNet implementation that can be trained on Cifar10 with SAM. Start the training by running `python3 train.py`
